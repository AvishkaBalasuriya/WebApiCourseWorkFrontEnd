window["Config"] = {
  LayoutURL: "http://34.233.140.188:2088/layout.aspx",
  ReportURL: "http://34.233.140.188:2088/report.aspx",
  AttachmentURL: "http://34.233.140.188:2088/file.aspx",
  SAPSyncURL: "http://35.168.148.54:2090",
};
