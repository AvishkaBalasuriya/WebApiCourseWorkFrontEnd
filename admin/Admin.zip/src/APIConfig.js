var APIURl = {
  URL: "https://webnibm.herokuapp.com/api/v1/",
};

module.exports = APIURl;
